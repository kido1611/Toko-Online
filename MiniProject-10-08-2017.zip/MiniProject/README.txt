READ ME

masalah : *masih belum tau cara bikin footer yang benar

-------------------------------

Home < index.html
  - diakses pertama kali website dibuka atau memencet tombol ada menu bar atau lewat tulisan pada halaman contact
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - tombol admin aktif (ketika admin login)
  - tombol cart pada table barang berfungsi untuk memasukan barang kedalam cart
  - jumlah baris dan kolom disesuaikan jumlah barang (normalnya 4x5)
  - kategori akan disesuaikan pada kategori database

Contact < contact_page.html
  - diakses dengan memencet tombol contact di footer
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*  

Login < login_page.html
  - diakses dengan memencet tombol pada menu bar atau pada halaman register
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
 

Register < register_page.html
  - diakses dengan memencet tombol pada halaman login
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - checkbox newsletter untuk pengiriminan berita ke email
  - eula term dapat di klik, berisi syarat dan ketentuan

Cart < cart_page.html
  - diakses dengan memencet gambar cart pada menu bar
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - besar baris dan kolom disesuaikan pembelian 

Admin < admin_page.html
  - diakses dengan memecencet tombol admin pada halaman home
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - combo box kategori disesuaikan dengan kategori pada database

Product < product_page.html
  - diakses dengan memencet barang yang dipilih pada halaman home
  - pada menu bar:login aktif, logout hidden (ketika user tidak aktif) *ini mungkin pake javascript (ga ngerti cara pakenya)*
  - pada menu bar:login hidden, logout aktif (ketika user login)       *ini mungkin pake javascript (ga ngerti cara pakenya)*
